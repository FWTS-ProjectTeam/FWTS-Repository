package com.teamf.fwts.dto;

import lombok.Data;

@Data
public class VerificationCodeDTO {
	private String code;
}